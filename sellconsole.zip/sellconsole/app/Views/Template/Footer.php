<div class="container py-3 text-white text-center">
    <span>&COPY Copyright Pond & Nice Console Shop</span>
</div>